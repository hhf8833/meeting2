INSERT INTO `sys_config` VALUES (1481244035229200386, '全局日志记录，如果开启则所有请求都将记录日志', 'SYS_LOG_GLOBAL_FLAG', 'false', 'Y', NULL, 1, 'file_config', 'N', NULL, NULL, NULL, NULL);
