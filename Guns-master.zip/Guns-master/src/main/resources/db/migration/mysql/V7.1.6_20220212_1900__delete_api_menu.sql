delete from sys_menu where menu_id in ('1399365117052919810', '1399366406616850433', '1339550467939639316');

DROP TABLE api_group;
DROP TABLE api_resource;
DROP TABLE api_resource_field;

delete from sys_role_menu where menu_id in ('1399365117052919810', '1399366406616850433', '1339550467939639316');
