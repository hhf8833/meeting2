ALTER TABLE `sys_app` ADD COLUMN `app_sort` int NULL COMMENT '排序' AFTER `status_flag`;
