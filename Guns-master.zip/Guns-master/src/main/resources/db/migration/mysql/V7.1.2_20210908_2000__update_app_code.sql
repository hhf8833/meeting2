UPDATE `sys_app` SET `app_code` = 'systemApp' WHERE `app_code` = 'system';
UPDATE `sys_menu` SET `app_code` = 'systemApp' WHERE `app_code` = 'system';