UPDATE `sys_config` SET `config_value` = concat(config_value, ',/webSocket/*') WHERE `config_id` = 1350666094452482049;
