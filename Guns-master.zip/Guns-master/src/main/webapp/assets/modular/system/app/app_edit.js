/**
 * 编辑应用
 */
layui.use(['form', 'admin', 'HttpRequest', 'iconPicker'], function () {
    var form = layui.form;
    var admin = layui.admin;
    var HttpRequest = layui.HttpRequest;
    var iconPicker = layui.iconPicker;

    // 获取应用详情
    var request = new HttpRequest(Feng.ctxPath + "/sysApp/detail?appId=" + Feng.getUrlParam("appId"), 'get');
    var result = request.start();

    form.val('appForm', result.data);

    // 表单提交事件
    form.on('submit(btnSubmit)', function (data) {
        var request = new HttpRequest(Feng.ctxPath + "/sysApp/edit", 'post', function (data) {
            Feng.success("修改成功!");
            admin.putTempData('formOk', true);
            admin.closeThisDialog();
        }, function (data) {
            Feng.error("修改失败!" + data.message);
            admin.closeThisDialog();
        });
        request.set(data.field);
        request.start(true);
    });

    //初始化图标选择
    iconPicker.render({
        elem: '#appIcon',
        type: 'fontClass',
        search: true,
        page: true,
        limit: 12,
        click: function (data) {
        }
    });

    iconPicker.checkIcon('iconPicker', result.data.appIcon);

});
